package com.example.procam

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.view.Gravity
import android.view.TextureView
import android.widget.*
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var tv: TextureView
    private lateinit var cam: CameraController
    private lateinit var info: TextView
    private lateinit var btnShutter: Button
    private var ids = listOf<String>()
    private var idx = 0
    private val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.texture)
        info = findViewById(R.id.info)
        btnShutter = findViewById(R.id.btnShutter)
        cam = CameraController(this, tv) { m -> runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() } }
        cam.onReady = { fitPreview(); setupControls(); cam.start() }
        ids = cam.cameraIds()

        findViewById<RadioGroup>(R.id.modes).setOnCheckedChangeListener { _, id ->
            val m = when (id) {
                R.id.rbVideo -> Mode.VIDEO; R.id.rbNight -> Mode.NIGHT
                R.id.rbHdr -> Mode.HDR; else -> Mode.PHOTO
            }
            btnShutter.text = if (m == Mode.VIDEO) "⏺" else "📷"
            cam.setMode(m)
        }
        btnShutter.setOnClickListener {
            if (cam.mode == Mode.VIDEO) {
                cam.toggleRecord()
                btnShutter.text = if (cam.recording) "⏺" else "⏹"
                btnShutter.postDelayed({ btnShutter.text = if (cam.recording) "⏹" else "⏺" }, 800)
            } else cam.capture()
        }
        findViewById<Button>(R.id.btnSwitch).setOnClickListener {
            if (ids.size > 1 && !cam.recording) {
                idx = (idx + 1) % ids.size
                Toast.makeText(this, cam.label(ids[idx]), Toast.LENGTH_SHORT).show()
                cam.open(ids[idx])
            }
        }
        findViewById<Switch>(R.id.swManual).setOnCheckedChangeListener { _, on -> cam.manual = on; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swFocus).setOnCheckedChangeListener { _, on -> cam.manualFocus = on; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swRaw).setOnCheckedChangeListener { _, on ->
            cam.rawEnabled = on && cam.hasRaw
            if (on && !cam.hasRaw) Toast.makeText(this, "RAW غير مدعوم في هذه العدسة", Toast.LENGTH_SHORT).show()
            cam.start()
        }
    }

    private fun setupControls() {
        val isoR = cam.isoRange; val expR = cam.expRange
        val sIso = findViewById<SeekBar>(R.id.seekIso)
        val sExp = findViewById<SeekBar>(R.id.seekShutter)
        val sFoc = findViewById<SeekBar>(R.id.seekFocus)
        if (isoR != null) {
            cam.iso = isoR.lower
            sIso.onChange { cam.iso = isoR.lower + (it * (isoR.upper - isoR.lower) / 1000); cam.refresh(); updateInfo() }
        }
        if (expR != null) {
            val hi = minOf(expR.upper, 1_000_000_000L).toDouble()
            val lo = expR.lower.toDouble()
            cam.exposureNs = lo.toLong()
            sExp.onChange { cam.exposureNs = (lo * (hi / lo).pow(it / 1000.0)).toLong(); cam.refresh(); updateInfo() }
        }
        sFoc.onChange { cam.focus = it / 1000f * cam.minFocus; cam.refresh(); updateInfo() }
        findViewById<Switch>(R.id.swRaw).isEnabled = cam.hasRaw
        findViewById<Switch>(R.id.swManual).isEnabled = cam.hasManual
        sIso.isEnabled = cam.hasManual; sExp.isEnabled = cam.hasManual; sFoc.isEnabled = cam.minFocus > 0f
        updateInfo()
    }

    private fun updateInfo() {
        val shutter = if (cam.exposureNs >= 500_000_000L) "%.1fs".format(cam.exposureNs / 1e9)
        else "1/${(1e9 / cam.exposureNs).toInt()}"
        info.text = buildString {
            append(if (cam.manual) "ISO ${cam.iso} • $shutter" else "تعريض تلقائي")
            append(" • ")
            append(if (cam.manualFocus) "تركيز %.1f د".format(cam.focus) else "AF")
            append(if (cam.hasRaw) " • RAW✔" else "")
        }
    }

    private fun fitPreview() {
        val w = resources.displayMetrics.widthPixels
        val h = w * cam.previewSize.width / cam.previewSize.height
        tv.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.TOP)
    }

    private fun SeekBar.onChange(f: (Int) -> Unit) {
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) f(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun openCamera() { if (ids.isNotEmpty()) cam.open(ids[idx]) }

    override fun onResume() {
        super.onResume()
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(perms, 1); return
        }
        if (tv.isAvailable) openCamera()
        else tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) = openCamera()
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.all { it == PackageManager.PERMISSION_GRANTED }) onResume()
        else Toast.makeText(this, "الأذونات مطلوبة", Toast.LENGTH_LONG).show()
    }

    override fun onPause() { cam.close(); super.onPause() }
    override fun onDestroy() { cam.release(); super.onDestroy() }
}
